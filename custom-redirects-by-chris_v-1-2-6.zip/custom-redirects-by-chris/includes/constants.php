<?php


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 


// Constants
define('CHRMRTNS_CUSTOM_REDIRECTS_TABLE', 'chrmrtns_custom_redirects');