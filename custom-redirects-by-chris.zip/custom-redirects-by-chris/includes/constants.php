<?php

// Constants
define('CHRMRTNS_CUSTOM_REDIRECTS_TABLE', 'chrmrtns_custom_redirects');